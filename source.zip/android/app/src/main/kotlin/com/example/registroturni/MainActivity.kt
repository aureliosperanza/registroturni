package com.example.registroturni

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
